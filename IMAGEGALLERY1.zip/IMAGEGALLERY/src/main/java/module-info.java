module com.example.imagegallery {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.imagegallery to javafx.fxml;
    exports com.example.imagegallery;

}