package com.example.imagegallery;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class HelloApplication extends Application {
    private static final int THUMBNAIL_SIZE = 100;
    private static final int FULL_SIZE = 400;
    private List<String> imagePaths = new ArrayList<>();
    private int currentIndex = 0; // Track the current index of the image
    private Stage stage;

    {
        // Properly loading images from the resources folder
        addImageToList("/com/example/imagegallery/images/image1.jpg");
        addImageToList("/com/example/imagegallery/images/image2.jpg");
        addImageToList("/com/example/imagegallery/images/image3.jpg");
        addImageToList("/com/example/imagegallery/images/image4.jpg");
        addImageToList("/com/example/imagegallery/images/image5.jpg");
        addImageToList("/com/example/imagegallery/images/image6.jpg");
    }

    private void addImageToList(String resourcePath) {
        try {
            String imagePath = getClass().getResource(resourcePath).toExternalForm();
            imagePaths.add(imagePath);
        } catch (Exception e) {
            System.out.println("Error loading image: " + resourcePath);
        }
    }

    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;
        showThumbnailView();
    }

    private void showThumbnailView() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.getStyleClass().add("grid-pane");

        int col = 0, row = 0;
        for (String path : imagePaths) {
            ImageView thumbnail = createThumbnail(path);
            grid.add(thumbnail, col, row);
            col++;
            if (col == 3) {
                col = 0;
                row++;
            }
        }

        BorderPane root = new BorderPane();
        root.setCenter(grid);
        Scene scene = new Scene(root, 400, 300);

        // Load CSS styling
        try {
            scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        } catch (Exception e) {
            System.out.println("Error loading stylesheet: " + e.getMessage());
        }

        stage.setScene(scene);
        stage.setTitle("Image Gallery");
        stage.show();
    }

    private ImageView createThumbnail(String imagePath) {
        Image image;
        try {
            image = new Image(imagePath);
        } catch (Exception e) {
            System.out.println("Error loading thumbnail: " + imagePath);
            return new ImageView(); // Return an empty ImageView if loading fails
        }

        ImageView thumbnail = new ImageView(image);
        thumbnail.setFitWidth(THUMBNAIL_SIZE);
        thumbnail.setFitHeight(THUMBNAIL_SIZE);
        thumbnail.getStyleClass().add("thumbnail");
        thumbnail.setOnMouseClicked(e -> showFullImageView(imagePaths.indexOf(imagePath))); // Pass index

        return thumbnail;
    }

    private void showFullImageView(int index) {
        currentIndex = index; // Update the current index when showing a new full image

        Image image;
        try {
            image = new Image(imagePaths.get(currentIndex));
        } catch (Exception e) {
            System.out.println("Error loading full-size image: " + imagePaths.get(currentIndex));
            return;
        }

        ImageView fullImage = new ImageView(image);
        fullImage.setFitWidth(FULL_SIZE);
        fullImage.setFitHeight(FULL_SIZE);
        fullImage.getStyleClass().add("full-image");

        Button backButton = new Button("Back to Gallery");
        backButton.setOnAction(e -> showThumbnailView());

        Button prevButton = new Button("Previous");
        prevButton.setOnAction(e -> {
            if (currentIndex > 0) {
                showFullImageView(currentIndex - 1); // Show the previous image
            }
        });

        Button nextButton = new Button("Next");
        nextButton.setOnAction(e -> {
            if (currentIndex < imagePaths.size() - 1) {
                showFullImageView(currentIndex + 1); // Show the next image
            }
        });

        HBox navBox = new HBox(10, prevButton, nextButton);
        navBox.setAlignment(Pos.CENTER);

        VBox layout = new VBox(10, fullImage, navBox, backButton);
        layout.setAlignment(Pos.CENTER);
        layout.getStyleClass().add("full-view-container");

        Scene scene = new Scene(layout, 600, 600);
        try {
            scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        } catch (Exception e) {
            System.out.println("Error loading stylesheet: " + e.getMessage());
        }

        stage.setScene(scene);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
