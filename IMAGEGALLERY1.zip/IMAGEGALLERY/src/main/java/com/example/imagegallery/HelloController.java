package com.example.imagegallery;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;

import java.util.Objects;

public class HelloController {
    @FXML
    private GridPane gridPane; // Ensure this is defined in your FXML file

    private final String[] imagePaths = {
            "/com/example/imagegallery/images/image1.jpg",
            "/com/example/imagegallery/images/image2.jpg",
            "/com/example/imagegallery/images/image3.jpg"
    };

    @FXML
    public void initialize() {
        loadThumbnails();
    }

    private void loadThumbnails() {
        int column = 0;
        int row = 0;

        for (String path : imagePaths) {
            Image image = new Image(Objects.requireNonNull(getClass().getResource(path)).toExternalForm());
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(100);  // Thumbnail size
            imageView.setFitHeight(100);
            imageView.setPreserveRatio(true);
            imageView.setOnMouseClicked(event -> openFullSizeImage(path));

            StackPane stackPane = new StackPane(imageView);
            gridPane.add(stackPane, column, row);

            column++;
            if (column == 3) {  // Adjust grid layout
                column = 0;
                row++;
            }
        }
    }

    private void openFullSizeImage(String imagePath) {
        Image fullImage = new Image(Objects.requireNonNull(getClass().getResource(imagePath)).toExternalForm());
        ImageView fullImageView = new ImageView(fullImage);
        fullImageView.setFitWidth(600);
        fullImageView.setPreserveRatio(true);

        StackPane stackPane = new StackPane(fullImageView);
        stackPane.setStyle("-fx-background-color: rgba(0, 0, 0, 0.8);");

        gridPane.getChildren().clear();
        gridPane.add(stackPane, 0, 0);

        stackPane.setOnMouseClicked(event -> loadThumbnails()); // Click to return to thumbnails
    }
}
